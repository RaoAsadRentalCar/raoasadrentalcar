RAO ASAD RENTAL CAR — WEBSITE + CMS STARTER

Included:
- index.html (premium website; fleet is read from content/vehicles.json)
- content/vehicles.json (12 editable cars)
- admin/index.html and admin/config.yml (Decap CMS interface using Netlify Git Gateway)
- images/ folder for uploaded car photos

Important: This is the complete website/CMS code package, but the live admin login will only work after the Netlify setup below. This cannot be fully activated from a ZIP alone.

ONE-TIME SETUP:
1. Upload/extract the contents of this ZIP into the ROOT of your existing GitHub repository. Do not upload the ZIP itself. Keep paths exactly: index.html, admin/, content/, images/.
2. In Netlify, connect the EXISTING site raoasadrentalcar to this GitHub repository (Site configuration / Build & deploy / Continuous deployment). Publish directory is the repository root; no build command is needed.
3. In Netlify, enable Identity (if available for this site), set registration to Invite only, then enable Git Gateway under Identity services. Invite your own email and accept the invite.
4. If Identity/Git Gateway is not available on your Netlify plan/account, this backend requires an alternative authenticated GitHub OAuth setup; do not expose a GitHub personal access token in browser code.
5. Wait for deploy. Open https://raoasadrentalcar.netlify.app/admin/ and sign in. Test editing one car on a deploy preview before relying on production.
6. For photo uploads, use the admin media picker; images are stored in /images.

Vehicle details and rates begin as "Request a quote" because exact rates were not supplied. Representative stock photos are placeholders; replace with your actual car photos in admin.

WhatsApp: +92 303 5736328. All rentals are with driver; self-drive option removed.
